import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  UserCircle,
  Bell,
  Shield,
  Link2,
  LogOut,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '@/stores/AppContext';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

const menuItems = [
  { id: 'account', label: 'Account', icon: UserCircle, path: '/settings' },
  { id: 'notifications', label: 'Notifications', icon: Bell, path: '/settings?tab=notifications' },
  { id: 'security', label: 'Security', icon: Shield, path: '/settings?tab=security' },
  { id: 'socials', label: 'Connected Socials', icon: Link2, path: '/settings?tab=socials' },
];

const backdropVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.25 } },
  exit: { opacity: 0, transition: { duration: 0.2 } },
};

const drawerVariants = {
  hidden: { x: '-100%', opacity: 0.8 },
  visible: {
    x: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 300,
      damping: 30,
      mass: 0.8,
    },
  },
  exit: {
    x: '-100%',
    opacity: 0.8,
    transition: {
      type: 'spring',
      stiffness: 400,
      damping: 35,
    },
  },
};

const contentVariants = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { delay: 0.08, duration: 0.25, ease: 'easeOut' as const },
  },
  exit: {
    opacity: 0,
    scale: 0.98,
    transition: { duration: 0.15 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, x: -12 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: { delay: 0.1 + i * 0.05, duration: 0.3, ease: 'easeOut' as const },
  }),
};

export function SideDrawer() {
  const { state, setDrawer, logout } = useApp();
  const navigate = useNavigate();

  const handleClose = () => setDrawer(false);

  const handleNavigate = (path: string) => {
    setDrawer(false);
    setTimeout(() => navigate(path), 250);
  };

  const handleLogout = () => {
    setDrawer(false);
    setTimeout(() => {
      logout();
      navigate('/login');
    }, 250);
  };

  return (
    <AnimatePresence>
      {state.drawerOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            variants={backdropVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={handleClose}
            className="fixed inset-0 z-[60] bg-black/25 backdrop-blur-sm"
          />

          {/* Main content scale effect */}
          <motion.div
            variants={contentVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="fixed inset-0 z-[60] pointer-events-none"
          >
            <div className="absolute inset-0 bg-white rounded-r-3xl shadow-2xl origin-left pointer-events-auto w-[82%] max-w-[320px] overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between px-5 pt-14 pb-4">
                <span className="text-lg font-bold text-[#111827]">Menu</span>
                <button
                  onClick={handleClose}
                  className="p-2 rounded-full bg-[#F7F8FA] hover:bg-[#E8ECF2] transition-colors active:scale-95"
                >
                  <X className="w-5 h-5 text-[#6B7280]" />
                </button>
              </div>

              {/* User info */}
              {state.user && (
                <div className="px-5 pb-5">
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-[#F3F1FF] to-[#E8F4FF]">
                    <div className="relative">
                      <img
                        src={state.user.avatar || ''}
                        alt={state.user.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm"
                      />
                      {state.user.verified && (
                        <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-[#6C63FF] rounded-full flex items-center justify-center border-2 border-white">
                          <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-[#111827] text-sm truncate">{state.user.name}</p>
                      <p className="text-xs text-[#6B7280] truncate">{state.user.email}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Menu items */}
              <div className="px-3 space-y-0.5">
                {menuItems.map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <motion.button
                      key={item.id}
                      custom={i}
                      variants={itemVariants}
                      initial="hidden"
                      animate="visible"
                      onClick={() => handleNavigate(item.path)}
                      className={cn(
                        'w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-colors',
                        'hover:bg-[#F7F8FA] active:bg-[#E8ECF2] active:scale-[0.98]'
                      )}
                    >
                      <div className="w-9 h-9 rounded-lg bg-[#F7F8FA] flex items-center justify-center">
                        <Icon className="w-[18px] h-[18px] text-[#6B7280]" />
                      </div>
                      <span className="flex-1 text-left text-sm font-medium text-[#111827]">{item.label}</span>
                      <ChevronRight className="w-4 h-4 text-[#9CA3AF]" />
                    </motion.button>
                  );
                })}
              </div>

              {/* Logout */}
              <div className="absolute bottom-8 left-0 right-0 px-5">
                <motion.button
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0, transition: { delay: 0.35 } }}
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-[#FEF2F2] text-[#EF4444] font-medium text-sm active:scale-[0.98] transition-transform"
                >
                  <LogOut className="w-4 h-4" />
                  Log Out
                </motion.button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
