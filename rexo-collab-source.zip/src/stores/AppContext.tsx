import React, { createContext, useContext, useReducer, useCallback } from 'react';
import type { User, Campaign, Application, Transaction, Notification } from '@/types';
import { mockUser, mockCampaigns, mockApplications, mockTransactions, mockNotifications } from '@/data/mockData';

interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  campaigns: Campaign[];
  applications: Application[];
  transactions: Transaction[];
  notifications: Notification[];
  drawerOpen: boolean;
  activeTab: string;
  isLoading: boolean;
}

type AppAction =
  | { type: 'LOGIN'; payload: User }
  | { type: 'LOGOUT' }
  | { type: 'SET_CAMPAIGNS'; payload: Campaign[] }
  | { type: 'SET_APPLICATIONS'; payload: Application[] }
  | { type: 'ADD_APPLICATION'; payload: Application }
  | { type: 'SET_TRANSACTIONS'; payload: Transaction[] }
  | { type: 'SET_NOTIFICATIONS'; payload: Notification[] }
  | { type: 'MARK_NOTIFICATION_READ'; payload: string }
  | { type: 'TOGGLE_DRAWER' }
  | { type: 'SET_DRAWER'; payload: boolean }
  | { type: 'SET_ACTIVE_TAB'; payload: string }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'UPDATE_USER'; payload: Partial<User> }
  | { type: 'ADD_CAMPAIGN'; payload: Campaign };

const initialState: AppState = {
  user: mockUser,
  isAuthenticated: true,
  campaigns: mockCampaigns,
  applications: mockApplications,
  transactions: mockTransactions,
  notifications: mockNotifications,
  drawerOpen: false,
  activeTab: 'home',
  isLoading: false,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'LOGIN':
      return { ...state, user: action.payload, isAuthenticated: true };
    case 'LOGOUT':
      return { ...state, user: null, isAuthenticated: false };
    case 'SET_CAMPAIGNS':
      return { ...state, campaigns: action.payload };
    case 'ADD_CAMPAIGN':
      return { ...state, campaigns: [action.payload, ...state.campaigns] };
    case 'SET_APPLICATIONS':
      return { ...state, applications: action.payload };
    case 'ADD_APPLICATION':
      return { ...state, applications: [...state.applications, action.payload] };
    case 'SET_TRANSACTIONS':
      return { ...state, transactions: action.payload };
    case 'SET_NOTIFICATIONS':
      return { ...state, notifications: action.payload };
    case 'MARK_NOTIFICATION_READ':
      return {
        ...state,
        notifications: state.notifications.map((n) =>
          n.id === action.payload ? { ...n, read: true } : n
        ),
      };
    case 'TOGGLE_DRAWER':
      return { ...state, drawerOpen: !state.drawerOpen };
    case 'SET_DRAWER':
      return { ...state, drawerOpen: action.payload };
    case 'SET_ACTIVE_TAB':
      return { ...state, activeTab: action.payload };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'UPDATE_USER':
      return { ...state, user: state.user ? { ...state.user, ...action.payload } : null };
    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  login: (user: User) => void;
  logout: () => void;
  toggleDrawer: () => void;
  setDrawer: (open: boolean) => void;
  setActiveTab: (tab: string) => void;
  applyToCampaign: (application: Application) => void;
  markNotificationRead: (id: string) => void;
  addCampaign: (campaign: Campaign) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  const login = useCallback((user: User) => dispatch({ type: 'LOGIN', payload: user }), []);
  const logout = useCallback(() => dispatch({ type: 'LOGOUT' }), []);
  const toggleDrawer = useCallback(() => dispatch({ type: 'TOGGLE_DRAWER' }), []);
  const setDrawer = useCallback((open: boolean) => dispatch({ type: 'SET_DRAWER', payload: open }), []);
  const setActiveTab = useCallback((tab: string) => dispatch({ type: 'SET_ACTIVE_TAB', payload: tab }), []);
  const applyToCampaign = useCallback((application: Application) => dispatch({ type: 'ADD_APPLICATION', payload: application }), []);
  const markNotificationRead = useCallback((id: string) => dispatch({ type: 'MARK_NOTIFICATION_READ', payload: id }), []);
  const addCampaign = useCallback((campaign: Campaign) => dispatch({ type: 'ADD_CAMPAIGN', payload: campaign }), []);

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        login,
        logout,
        toggleDrawer,
        setDrawer,
        setActiveTab,
        applyToCampaign,
        markNotificationRead,
        addCampaign,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
