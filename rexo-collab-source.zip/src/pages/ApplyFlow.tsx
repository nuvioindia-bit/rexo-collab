import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Check, ArrowRight, Link2, Upload } from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '@/stores/AppContext';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import type { Application } from '@/types';

const steps = [
  { id: 1, label: 'Category', title: 'Content Category' },
  { id: 2, label: 'Audience', title: 'Audience Stats' },
  { id: 3, label: 'Socials', title: 'Social Links' },
  { id: 4, label: 'Pricing', title: 'Your Rate' },
  { id: 5, label: 'Portfolio', title: 'Portfolio' },
  { id: 6, label: 'Submit', title: 'Review & Submit' },
];

const categories = ['Fashion', 'Technology', 'Beauty', 'Fitness', 'Travel', 'Lifestyle', 'Food', 'Gaming'];

export default function ApplyFlow() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { state, applyToCampaign } = useApp();
  const campaign = state.campaigns.find((c) => c.id === id);

  const [currentStep, setCurrentStep] = useState(0);
  const [category, setCategory] = useState('');
  const [followers, setFollowers] = useState('');
  const [engagement, setEngagement] = useState('');
  const [platform, setPlatform] = useState('Instagram');
  const [instagram, setInstagram] = useState('');
  const [youtube, setYoutube] = useState('');
  const [tiktok, setTiktok] = useState('');
  const [rate, setRate] = useState(campaign?.payout ? String(campaign.payout) : '');
  const [negotiable, setNegotiable] = useState(true);
  const [pitch, setPitch] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!campaign) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-sm text-[#6B7280]">Campaign not found</p>
      </div>
    );
  }

  const canProceed = () => {
    switch (currentStep) {
      case 0: return !!category;
      case 1: return !!followers && !!engagement;
      case 2: return !!instagram || !!youtube || !!tiktok;
      case 3: return !!rate;
      case 4: return !!pitch;
      case 5: return true;
      default: return false;
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep((s) => s + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep((s) => s - 1);
    } else {
      navigate(-1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const application: Application = {
      id: `a-${Date.now()}`,
      campaignId: campaign.id,
      creatorId: state.user?.id || 'u1',
      creatorName: state.user?.name || 'Alex Rivera',
      creatorAvatar: state.user?.avatar,
      status: 'pending',
      pitch,
      proposedRate: Number(rate),
      portfolioLinks: [instagram, youtube, tiktok].filter(Boolean),
      socialLinks: { instagram, youtube, tiktok },
      audienceStats: { followers: Number(followers), engagement: Number(engagement), platform },
      createdAt: new Date().toISOString().split('T')[0],
    };

    applyToCampaign(application);
    toast.success('Application submitted successfully!');
    navigate('/campaigns');
  };

  const slideVariants = {
    enter: (direction: number) => ({ x: direction > 0 ? 60 : -60, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (direction: number) => ({ x: direction > 0 ? -60 : 60, opacity: 0 }),
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-3">
            <p className="text-sm text-[#6B7280]">Select your primary content category for this campaign</p>
            <div className="grid grid-cols-2 gap-2.5">
              {categories.map((cat) => (
                <motion.button
                  key={cat}
                  whileTap={{ scale: 0.96 }}
                  onClick={() => setCategory(cat)}
                  className={`p-3.5 rounded-xl border-2 text-sm font-medium text-left transition-all ${
                    category === cat
                      ? 'border-[#6C63FF] bg-[#F3F1FF] text-[#6C63FF]'
                      : 'border-[#E8ECF2] bg-white text-[#111827]'
                  }`}
                >
                  {cat}
                </motion.button>
              ))}
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Total Followers</label>
              <Input
                type="number"
                placeholder="e.g. 245000"
                value={followers}
                onChange={(e) => setFollowers(e.target.value)}
                className="h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Engagement Rate (%)</label>
              <Input
                type="number"
                placeholder="e.g. 4.8"
                value={engagement}
                onChange={(e) => setEngagement(e.target.value)}
                className="h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Primary Platform</label>
              <div className="flex gap-2">
                {['Instagram', 'YouTube', 'TikTok'].map((p) => (
                  <button
                    key={p}
                    onClick={() => setPlatform(p)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-medium transition-all ${
                      platform === p
                        ? 'bg-[#6C63FF] text-white'
                        : 'bg-[#F7F8FA] text-[#6B7280] border border-[#E8ECF2]'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Instagram URL</label>
              <div className="relative">
                <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                <Input
                  placeholder="https://instagram.com/..."
                  value={instagram}
                  onChange={(e) => setInstagram(e.target.value)}
                  className="pl-10 h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">YouTube URL</label>
              <div className="relative">
                <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                <Input
                  placeholder="https://youtube.com/..."
                  value={youtube}
                  onChange={(e) => setYoutube(e.target.value)}
                  className="pl-10 h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">TikTok URL</label>
              <div className="relative">
                <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                <Input
                  placeholder="https://tiktok.com/@..."
                  value={tiktok}
                  onChange={(e) => setTiktok(e.target.value)}
                  className="pl-10 h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm"
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Proposed Rate (USD)</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#6B7280] font-medium">$</span>
                <Input
                  type="number"
                  value={rate}
                  onChange={(e) => setRate(e.target.value)}
                  className="pl-7 h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm font-semibold text-[#111827]"
                />
              </div>
              <p className="text-[11px] text-[#6B7280] mt-1.5">Campaign budget: ${campaign.payout.toLocaleString()}</p>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={negotiable}
                onChange={(e) => setNegotiable(e.target.checked)}
                className="w-4 h-4 rounded border-[#E8ECF2] accent-[#6C63FF]"
              />
              <span className="text-sm text-[#111827]">Rate is negotiable</span>
            </label>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Your Pitch</label>
              <textarea
                placeholder="Tell the brand why you're perfect for this campaign..."
                value={pitch}
                onChange={(e) => setPitch(e.target.value)}
                rows={4}
                className="w-full px-4 py-3 rounded-xl bg-[#F7F8FA] border border-[#E8ECF2] text-sm text-[#111827] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#6C63FF]/20 focus:border-[#6C63FF] resize-none"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Portfolio Links</label>
              <motion.button
                whileTap={{ scale: 0.97 }}
                className="w-full flex items-center justify-center gap-2 h-12 rounded-xl border-2 border-dashed border-[#E8ECF2] text-sm text-[#6B7280] hover:border-[#6C63FF] hover:text-[#6C63FF] transition-colors"
              >
                <Upload className="w-4 h-4" />
                Add portfolio links
              </motion.button>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-4">
            <div className="bg-[#F7F8FA] rounded-2xl p-4 border border-[#E8ECF2]">
              <h4 className="text-xs font-bold text-[#111827] uppercase tracking-wider mb-3">Application Summary</h4>
              <div className="space-y-2.5 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#6B7280]">Category</span>
                  <span className="font-medium text-[#111827]">{category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6B7280]">Platform</span>
                  <span className="font-medium text-[#111827]">{platform}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6B7280]">Followers</span>
                  <span className="font-medium text-[#111827]">{Number(followers).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6B7280]">Engagement</span>
                  <span className="font-medium text-[#111827]">{engagement}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6B7280]">Proposed Rate</span>
                  <span className="font-medium text-[#111827]">${Number(rate).toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-2 p-3 rounded-xl bg-[#F3F1FF]">
              <Check className="w-4 h-4 text-[#6C63FF] mt-0.5 flex-shrink-0" />
              <p className="text-xs text-[#6C63FF] leading-relaxed">
                By submitting, you confirm all information is accurate and agree to the campaign terms.
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="px-5 pt-4 pb-2 flex items-center gap-3">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleBack}
          className="w-10 h-10 rounded-xl bg-[#F7F8FA] flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-[#111827]" />
        </motion.button>
        <div className="flex-1">
          <h1 className="text-sm font-bold text-[#111827]">{steps[currentStep].title}</h1>
          <p className="text-[10px] text-[#6B7280]">Step {currentStep + 1} of {steps.length}</p>
        </div>
      </div>

      {/* Progress */}
      <div className="px-5 mb-6">
        <div className="flex gap-1.5">
          {steps.map((s, i) => (
            <div
              key={s.id}
              className={`h-1 rounded-full flex-1 transition-all duration-500 ${
                i <= currentStep ? 'bg-[#6C63FF]' : 'bg-[#E8ECF2]'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-5 overflow-y-auto no-scrollbar">
        <AnimatePresence mode="wait" custom={1}>
          <motion.div
            key={currentStep}
            custom={1}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.3, ease: 'easeInOut' }}
          >
            {renderStepContent()}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Footer CTA */}
      <div className="px-5 py-4 border-t border-[#E8ECF2]">
        {currentStep < steps.length - 1 ? (
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleNext}
            disabled={!canProceed()}
            className={`w-full h-14 rounded-2xl font-semibold text-sm transition-all ${
              canProceed()
                ? 'bg-gradient-to-r from-[#6C63FF] to-[#4EA8FF] text-white shadow-float'
                : 'bg-[#F7F8FA] text-[#9CA3AF] cursor-not-allowed'
            }`}
          >
            <span className="flex items-center justify-center gap-2">
              Continue <ArrowRight className="w-4 h-4" />
            </span>
          </motion.button>
        ) : (
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="w-full h-14 rounded-2xl font-semibold text-sm bg-gradient-to-r from-[#6C63FF] to-[#4EA8FF] text-white shadow-float transition-all"
          >
            {isSubmitting ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
            ) : (
              <span className="flex items-center justify-center gap-2">
                <Check className="w-4 h-4" /> Submit Application
              </span>
            )}
          </motion.button>
        )}
      </div>
    </div>
  );
}
