import { motion } from 'motion/react';
import { TrendingUp, Megaphone, CheckCircle, DollarSign, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/stores/AppContext';
import { CampaignCarousel } from '@/components/campaign/CampaignCarousel';
import { CampaignCard } from '@/components/campaign/CampaignCard';
import { MobileLayout } from '@/components/layout/MobileLayout';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

export default function Home() {
  const navigate = useNavigate();
  const { state } = useApp();
  const { user, campaigns } = state;

  const featuredCampaigns = campaigns.slice(0, 3);
  const trendingCampaigns = campaigns.slice(1, 4);

  const stats = [
    {
      label: 'Applied',
      value: user?.stats?.campaignsCompleted ? String(user.stats.campaignsCompleted + 5) : '12',
      icon: Megaphone,
      color: 'from-[#6C63FF] to-[#8B5CF6]',
    },
    {
      label: 'Approved',
      value: user?.stats?.campaignsCompleted ? String(user.stats.campaignsCompleted) : '8',
      icon: CheckCircle,
      color: 'from-[#22C55E] to-[#34D399]',
    },
    {
      label: 'Earnings',
      value: `$${(user?.stats?.totalEarned || 0).toLocaleString()}`,
      icon: DollarSign,
      color: 'from-[#4EA8FF] to-[#60A5FA]',
    },
  ];

  return (
    <MobileLayout title="Rexo" transparentTopBar>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="pb-6"
      >
        {/* Welcome Section */}
        <motion.div variants={itemVariants} className="px-5 pt-4 pb-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-[#6B7280] font-medium">Welcome back</p>
              <h2 className="text-xl font-bold text-[#111827] mt-0.5">{user?.name?.split(' ')[0] || 'Creator'}</h2>
            </div>
            {user?.verified && (
              <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-[#F3F1FF]">
                <CheckCircle className="w-3 h-3 text-[#6C63FF]" />
                <span className="text-[10px] font-semibold text-[#6C63FF]">Verified</span>
              </div>
            )}
          </div>
        </motion.div>

        {/* Stats Row */}
        <motion.div variants={itemVariants} className="px-5 mt-4">
          <div className="grid grid-cols-3 gap-2.5">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  whileTap={{ scale: 0.97 }}
                  className="bg-white rounded-2xl border border-[#E8ECF2] p-3 shadow-card"
                >
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center mb-2`}>
                    <Icon className="w-3.5 h-3.5 text-white" />
                  </div>
                  <p className="text-base font-bold text-[#111827]">{stat.value}</p>
                  <p className="text-[10px] text-[#6B7280] font-medium">{stat.label}</p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Featured Carousel */}
        <motion.div variants={itemVariants} className="mt-6">
          <div className="flex items-center justify-between px-5 mb-3">
            <h3 className="text-sm font-bold text-[#111827]">Featured Campaigns</h3>
            <button
              onClick={() => navigate('/campaigns')}
              className="flex items-center gap-0.5 text-xs font-medium text-[#6C63FF]"
            >
              See all <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <CampaignCarousel
            campaigns={featuredCampaigns}
            onSelect={(c) => navigate(`/campaigns/${c.id}`)}
          />
        </motion.div>

        {/* Trending */}
        <motion.div variants={itemVariants} className="mt-6 px-5">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-[#6C63FF]" />
            <h3 className="text-sm font-bold text-[#111827]">Trending Now</h3>
          </div>
          <div className="space-y-3">
            {trendingCampaigns.map((campaign, i) => (
              <CampaignCard
                key={campaign.id}
                campaign={campaign}
                index={i}
                onClick={() => navigate(`/campaigns/${campaign.id}`)}
                compact
              />
            ))}
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div variants={itemVariants} className="mt-6 px-5">
          <div className="bg-gradient-to-r from-[#F3F1FF] to-[#E8F4FF] rounded-2xl p-4 border border-[#E8ECF2]">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-[#111827]">Complete your profile</h4>
                <p className="text-xs text-[#6B7280] mt-0.5">Get discovered by top brands</p>
              </div>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/profile')}
                className="px-4 py-2 rounded-xl bg-[#6C63FF] text-white text-xs font-semibold shadow-sm"
              >
                Edit Profile
              </motion.button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </MobileLayout>
  );
}
