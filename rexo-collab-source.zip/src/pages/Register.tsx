import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, ArrowRight, Check, Sparkles, Building2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/stores/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import type { UserRole } from '@/types';

export default function Register() {
  const navigate = useNavigate();
  const { login } = useApp();
  const [step, setStep] = useState<'role' | 'details'>('role');
  const [role, setRole] = useState<UserRole>('creator');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleRoleSelect = (selectedRole: UserRole) => {
    setRole(selectedRole);
    setStep('details');
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) {
      toast.error('Please fill in all fields');
      return;
    }
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    login({
      id: 'u-new',
      email,
      name,
      role,
      avatar: role === 'creator'
        ? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face'
        : 'https://images.unsplash.com/photo-1560179708-fd1db2e9dfae?w=200&h=200&fit=crop',
    });
    toast.success('Account created successfully!');
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <div className="flex-1 flex flex-col justify-center px-6 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#6C63FF] to-[#4EA8FF] flex items-center justify-center mb-5 shadow-float">
            <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-[#111827] tracking-tight">
            {step === 'role' ? 'Get started' : 'Create account'}
          </h1>
          <p className="text-sm text-[#6B7280] mt-1.5">
            {step === 'role' ? 'Choose your account type' : 'Fill in your details to join'}
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          {step === 'role' ? (
            <motion.div
              key="role"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-3"
            >
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={() => handleRoleSelect('creator')}
                className="w-full flex items-center gap-4 p-4 rounded-2xl border-2 border-[#E8ECF2] bg-white hover:border-[#6C63FF] hover:bg-[#F3F1FF]/30 transition-all text-left group"
              >
                <div className="w-12 h-12 rounded-xl bg-[#F3F1FF] flex items-center justify-center group-hover:bg-[#6C63FF] transition-colors">
                  <Sparkles className="w-5 h-5 text-[#6C63FF] group-hover:text-white transition-colors" />
                </div>
                <div>
                  <p className="font-semibold text-[#111827] text-sm">Creator / Influencer</p>
                  <p className="text-xs text-[#6B7280] mt-0.5">Browse campaigns and apply for brand deals</p>
                </div>
                <ArrowRight className="w-4 h-4 text-[#9CA3AF] ml-auto group-hover:text-[#6C63FF] transition-colors" />
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={() => handleRoleSelect('brand')}
                className="w-full flex items-center gap-4 p-4 rounded-2xl border-2 border-[#E8ECF2] bg-white hover:border-[#4EA8FF] hover:bg-[#E8F4FF]/30 transition-all text-left group"
              >
                <div className="w-12 h-12 rounded-xl bg-[#E8F4FF] flex items-center justify-center group-hover:bg-[#4EA8FF] transition-colors">
                  <Building2 className="w-5 h-5 text-[#4EA8FF] group-hover:text-white transition-colors" />
                </div>
                <div>
                  <p className="font-semibold text-[#111827] text-sm">Brand / Company</p>
                  <p className="text-xs text-[#6B7280] mt-0.5">Post campaigns and find creators</p>
                </div>
                <ArrowRight className="w-4 h-4 text-[#9CA3AF] ml-auto group-hover:text-[#4EA8FF] transition-colors" />
              </motion.button>
            </motion.div>
          ) : (
            <motion.form
              key="details"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              onSubmit={handleRegister}
              className="space-y-4"
            >
              <div className="flex items-center gap-2 mb-4">
                <button
                  type="button"
                  onClick={() => setStep('role')}
                  className="text-xs text-[#6B7280] hover:text-[#111827] transition-colors"
                >
                  ← Back
                </button>
                <div className="flex items-center gap-1.5">
                  {role === 'creator' ? (
                    <Sparkles className="w-3.5 h-3.5 text-[#6C63FF]" />
                  ) : (
                    <Building2 className="w-3.5 h-3.5 text-[#4EA8FF]" />
                  )}
                  <span className="text-xs font-medium text-[#111827]">
                    {role === 'creator' ? 'Creator' : 'Brand'} account
                  </span>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#111827] mb-1.5 block">
                  {role === 'creator' ? 'Full Name' : 'Company Name'}
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                  <Input
                    type="text"
                    placeholder={role === 'creator' ? 'Alex Rivera' : 'Nova Apparel'}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="pl-10 h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm focus:ring-2 focus:ring-[#6C63FF]/20 focus:border-[#6C63FF]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                  <Input
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm focus:ring-2 focus:ring-[#6C63FF]/20 focus:border-[#6C63FF]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#111827] mb-1.5 block">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                  <Input
                    type="password"
                    placeholder="Min 8 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 h-12 bg-[#F7F8FA] border-[#E8ECF2] rounded-xl text-sm focus:ring-2 focus:ring-[#6C63FF]/20 focus:border-[#6C63FF]"
                  />
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Check className="w-4 h-4 text-[#6C63FF] mt-0.5 flex-shrink-0" />
                <p className="text-[11px] text-[#6B7280] leading-relaxed">
                  By creating an account, you agree to our Terms of Service and Privacy Policy
                </p>
              </div>

              <motion.div whileTap={{ scale: 0.98 }}>
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-12 rounded-xl bg-gradient-to-r from-[#6C63FF] to-[#4EA8FF] text-white font-semibold text-sm shadow-float hover:opacity-95 transition-opacity"
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <span className="flex items-center justify-center gap-2">
                      Create Account <ArrowRight className="w-4 h-4" />
                    </span>
                  )}
                </Button>
              </motion.div>
            </motion.form>
          )}
        </AnimatePresence>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="px-6 pb-8 text-center"
      >
        <p className="text-xs text-[#6B7280]">
          Already have an account?{' '}
          <button onClick={() => navigate('/login')} className="font-semibold text-[#6C63FF]">
            Sign in
          </button>
        </p>
      </motion.div>
    </div>
  );
}
