# Requirements Document

## 1. Application Overview

**Application Name**: Rexo Collab

**Description**: A mobile-first creator marketplace connecting brands with creators/influencers. Brands post campaigns, creators browse and apply, and the platform facilitates collaboration through application management and payment processing.

---

## 2. Users and Usage Scenarios

### 2.1 Target Users

**Brand Users**:

- Companies seeking creator partnerships
- Marketing teams managing influencer campaigns

**Creator Users**:

- Content creators and influencers
- Social media personalities seeking brand collaborations

### 2.2 Core Usage Scenarios

**Brand Scenario**:

- Post campaign with requirements and budget
- Review creator applications
- Select and manage collaborations
- Process payments through wallet

**Creator Scenario**:

- Browse available campaigns
- Apply to relevant opportunities
- Manage profile and portfolio
- Receive payments through wallet

---

## 3. Page Structure and Functionality

### 3.1 Page Hierarchy

```
Application Root
├── Authentication
│   ├── Login
│   └── Registration
├── Main Navigation (Bottom Bar)
│   ├── Home
│   ├── Campaigns
│   ├── Wallet
│   └── Profile
├── Side Drawer Menu
│   ├── Account Settings
│   ├── Notifications Settings
│   ├── Security Settings
│   ├── Connected Socials
│   └── Logout
└── Campaign Details
    └── Application Flow
```

### 3.2 Authentication Pages

#### 3.2.1 Registration Page

- User type selection (Brand / Creator)
- Email input
- Password input
- Registration submission
- Navigate to login after successful registration

#### 3.2.2 Login Page

- Email input
- Password input
- Login submission
- Navigate to home after successful login

### 3.3 Home Screen

**For Creators**:

- Featured campaign carousel displaying top campaigns
- Personal stats overview (applications submitted, active collaborations)
- Trending campaigns list
- Quick access to apply for campaigns

**For Brands**:

- Active campaigns overview
- Application statistics (pending, approved, rejected)
- Quick access to post new campaign
- Recent creator applications

### 3.4 Campaigns Screen

**For Creators**:

- Campaign list with filters
- Each campaign card displays:
  - Brand logo
  - Campaign title
  - Payout amount
  - Creator requirements
  - Application deadline
  - Apply button
- Search functionality
- Filter by category, payout range, deadline

**For Brands**:

- List of own posted campaigns
- Campaign status (active, closed, draft)
- Create new campaign button
- Edit/delete campaign options

### 3.5 Campaign Details Page

**For Creators**:

- Full campaign description
- Brand information
- Detailed requirements
- Deliverables expected
- Timeline and deadline
- Payout details
- Apply button (if not already applied)
- Application status (if already applied)

**For Brands**:

- Campaign overview
- List of received applications
- Application review interface
- Approve/reject application actions

### 3.6 Creator Application Flow

Multi-step form accessed from campaign details:

**Step 1: Category Selection**

- Select content category (Fashion, Tech, Lifestyle, etc.)

**Step 2: Audience Statistics**

- Total followers
- Average engagement rate
- Primary platform

**Step 3: Social Links**

- Instagram URL
- YouTube URL
- TikTok URL
- Other platforms

**Step 4: Pricing**

- Proposed rate for campaign
- Negotiable option

**Step 5: Portfolio**

- Upload previous work samples
- Add portfolio links

**Step 6: Submit**

- Review all information
- Submit application
- Confirmation message

### 3.7 Wallet Screen

**For Creators**:

- Current balance display
- Earnings card showing total earned
- Payout history list with:
  - Campaign name
  - Amount
  - Date
  - Status (pending, completed)
- Withdraw button
- Transaction details

**For Brands**:

- Payment history
- Pending payments
- Completed transactions
- Payment method management

### 3.8 Profile Screen

**For Creators**:

- Profile photo
- Bio
- Analytics overview:
  - Total applications
  - Acceptance rate
  - Completed campaigns
- Connected social accounts
- Engagement statistics
- Portfolio showcase
- Verification badge (if verified)
- Edit profile button
- Settings access

**For Brands**:

- Company logo
- Company description
- Campaign statistics:
  - Total campaigns posted
  - Active campaigns
  - Completed collaborations
- Edit profile button
- Settings access

### 3.9 Settings (Side Drawer Menu)

#### 3.9.1 Account Settings

- Edit email
- Change password
- Account type display

#### 3.9.2 Notifications Settings

- Email notifications toggle
- Push notifications toggle
- Notification preferences by type

#### 3.9.3 Security Settings

- Two-factor authentication toggle
- Login history
- Active sessions management

#### 3.9.4 Connected Socials

- Link/unlink social media accounts
- Verify account ownership

#### 3.9.5 Logout

- Logout confirmation
- Clear session and return to login

### 3.10 Navigation Components

#### 3.10.1 Bottom Navigation Bar

- Four tabs: Home, Campaigns, Wallet, Profile
- Active tab indicator
- Tab switching functionality

#### 3.10.2 Top Menu Button

- Three-line menu icon (top-left)
- Opens side drawer on tap

#### 3.10.3 Side Drawer

- Overlay background
- Menu items:
  - Account
  - Notifications
  - Security
  - Connected Socials
  - Logout
- Close drawer on selection or background tap

---

## 4. Business Rules and Logic

### 4.1 User Registration and Login

- Users must register as either Brand or Creator
- User type cannot be changed after registration
- Email must be unique
- Password must meet minimum security requirements

### 4.2 Campaign Posting (Brands Only)

- Brands can post unlimited campaigns
- Each campaign must include:
  - Title
  - Description
  - Requirements
  - Payout amount
  - Deadline
- Campaigns can be saved as draft
- Active campaigns are visible to all creators

### 4.3 Campaign Application (Creators Only)

- Creators can apply to multiple campaigns
- One application per campaign per creator
- Applications cannot be edited after submission
- Application status: Pending, Approved, Rejected

### 4.4 Application Review (Brands Only)

- Brands review applications for their campaigns
- Brands can approve or reject applications
- Once approved, creator is notified
- Rejected applications cannot be resubmitted

### 4.5 Wallet and Payments

- Creators receive payments after campaign completion
- Payments are processed to wallet
- Creators can withdraw funds from wallet
- Minimum withdrawal amount applies
- Transaction history is maintained

### 4.6 Profile Management

- Users can edit profile information
- Creators must maintain updated social links
- Profile completeness affects visibility

---

## 5. Exceptions and Edge Cases

| Scenario                                                 | Handling                                              |
| -------------------------------------------------------- | ----------------------------------------------------- |
| User attempts to apply after deadline                    | Display error message, disable apply button           |
| Creator applies without complete profile                 | Prompt to complete profile before applying            |
| Brand tries to delete campaign with pending applications | Show warning, require confirmation                    |
| Wallet balance insufficient for withdrawal               | Display error, show minimum amount required           |
| User loses connection during application submission      | Save draft locally, allow resume                      |
| Duplicate email during registration                      | Display error, prompt to login or use different email |
| Invalid social media URL format                          | Display validation error, prevent submission          |
| Campaign payout amount is zero or negative               | Prevent campaign creation, show validation error      |

---

## 6. Acceptance Criteria

**Creator User Journey**:

1. Creator registers account with email and password
2. Creator completes profile with social links and portfolio
3. Creator browses campaigns on Campaigns screen
4. Creator selects a campaign and views details
5. Creator completes multi-step application form
6. Creator submits application and receives confirmation
7. Creator checks application status on Profile screen
8. After approval, creator views payment in Wallet

**Brand User Journey**:

1. Brand registers account with email and password
2. Brand completes company profile
3. Brand creates new campaign with requirements and budget
4. Brand publishes campaign
5. Brand receives creator applications
6. Brand reviews applications and approves suitable creator
7. Brand processes payment through Wallet after campaign completion

---

## 7. Out of Scope for Current Release

- Real-time chat between brands and creators
- Advanced analytics dashboard with charts and graphs
- Campaign performance tracking and metrics
- Automated matching algorithm between brands and creators
- Multi-language support
- Dark theme option
- In-app messaging system
- Campaign templates library
- Bulk application management
- Export data functionality
- API integrations with social media platforms for automatic stats sync
- Video call functionality for interviews
- Contract generation and e-signature
- Dispute resolution system
- Rating and review system for brands and creators
- Referral program
- Subscription tiers or premium features
- Advanced search with AI-powered recommendations

First User Jo bhi Login karega vo es Application ka admin ban jayega and admin ko super Admin bnana es app me vo sab kuch edit or remove kar skata hai payment magnet user management it's and everything sab kuch control kar sakta hai es app me jo jo available hai vo ok
